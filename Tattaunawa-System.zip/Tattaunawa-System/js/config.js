
export const config = {

    'NS_KEY': process.env.nodal_savvy_key
}